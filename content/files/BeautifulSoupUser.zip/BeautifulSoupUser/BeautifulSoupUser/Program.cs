﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IronPython.Hosting;

namespace BeautifulSoupUser
{
    class Program
    {
        static void Main(string[] args)
        {
            // This demo needs IronPython to be installed (http://ironpython.net/)
            // and BeautifulSoup (http://www.crummy.com/software/BeautifulSoup/#Download)
            //
            // The purpose of the sample is to use a library called BeautifulSoup 
            // This is a library for parsing HTML, even if it's badly formatted.
            // We are going to use this library in our C# program

            // 1. Create the Python engine
            var engine = Python.CreateEngine();
            // 2. Adding the search path for libraries. Python engine will use this when you do any import
            engine.SetSearchPaths(new string[] { @"C:\Program Files\IronPython 2.7\Lib" });

            // 3. import the library. This is equivalent to this Python code
            // import BeautifulSoup
            var BeautifulSoupModule = engine.ImportModule("BeautifulSoup");

            // Now we get the Python class BeautifulSoup from the module
            // We cast it to a function, so we can call it. In Python, an instance
            // of a class can be used as a function, like this Python code
            // 
            // bs = BeautifulSoup(doc)
            var BeautifulSoup = BeautifulSoupModule.GetVariable<Func<object, object>>("BeautifulSoup");

            string sample = @"
<html>
    <p>Hello <i>my friend</p>
    <p>Pleased to meet you</p>
</html>";

            // Now we are creating an instance of BeautifulSoup
            dynamic bs = BeautifulSoup(sample);
            // This will print a pretty-printed version of the HTML document, just like this
            // 
            //<html>
            // <p>
            //  Hello
            //  <i>
            //   my friend
            //  </i>
            // </p>
            // <p>
            //  Pleased to meet you
            // </p>
            //</html>
            //
            // if you notice, BeautifulSoup parsed the document correctly & corrected the italic tag ;)            
            Console.WriteLine(bs.prettify());
            Console.WriteLine("----------------------------");

            // these members are **dynamically** added to bs, defined by the structure of the document.
            // This is an example of the used of dynamic programming features
            Console.WriteLine(bs.html.p.prettify());

            Console.ReadLine();
        }
    }
}
